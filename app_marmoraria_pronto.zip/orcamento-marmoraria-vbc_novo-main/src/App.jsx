export default function App() {
  return (
    <h1 style={{ textAlign: "center", marginTop: "50px" }}>
      Projeto funcionando! 🚀
    </h1>
  );
}
